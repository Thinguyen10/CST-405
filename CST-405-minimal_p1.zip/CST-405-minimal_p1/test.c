int x;
int y;
int z;

x = 10;
y = 20;
z = x + y;
print(z);

x = z + 5;
print(x);

y = x + y + z;
print(y);